# Split SQL script file into list of commands
import os
import sqlparse
from tqdm import tqdm


class SplitCommands:
    def __init__(self, text):
        # Check if text is a file_path or a string
        if os.path.isfile(text):
            with open(text, 'r') as fd:
                self.sql_data = fd.read()
        else:
            self.sql_data = text

    def __call__(self):
        return self.__iter__()

    def __iter__(self):
        return iter(self.parse)

    def __len__(self):
        return len(self.parse)

    @property
    def parse(self):
        return sqlparse.split(self.sql_data)

    @property
    def split(self):
        results = []
        current = ''
        state = None
        for c in tqdm(self.sql_data, total=len(self.sql_data), desc='Parsing SQL script file', unit='chars'):
            if state is None:  # default state, outside of special entity
                current += c
                if c in '"\'':
                    # quoted string
                    state = c
                elif c == '-':
                    # probably "--" comment
                    state = '-'
                elif c == '/':
                    # probably '/*' comment
                    state = '/'
                elif c == ';':
                    # remove it from the statement
                    current = current[:-1].strip()
                    # and save current stmt unless empty
                    if current:
                        results.append(current)
                    current = ''
            elif state == '-':
                if c != '-':
                    # not a comment
                    state = None
                    current += c
                    continue
                # remove first minus
                current = current[:-1]
                # comment until end of line
                state = '--'
            elif state == '--':
                if c == '\n':
                    # end of comment
                    # and we do include this newline
                    current += c
                    state = None
                # else just ignore
            elif state == '/':
                if c != '*':
                    state = None
                    current += c
                    continue
                # remove starting slash
                current = current[:-1]
                # multiline comment
                state = '/*'
            elif state == '/*':
                if c == '*':
                    # probably end of comment
                    state = '/**'
            elif state == '/**':
                if c == '/':
                    state = None
                else:
                    # not an end
                    state = '/*'
            elif state[0] in '"\'':
                current += c
                if state.endswith('\\'):
                    # prev was backslash, don't check for ender
                    # just revert to regular state
                    state = state[0]
                    continue
                elif c == '\\':
                    # don't check next char
                    state += '\\'
                    continue
                elif c == state[0]:
                    # end of quoted string
                    state = None
            else:
                raise Exception('Illegal state %s' % state)

        if current:
            current = current.rstrip(';').strip()
            if current:
                results.append(current)

        return results
